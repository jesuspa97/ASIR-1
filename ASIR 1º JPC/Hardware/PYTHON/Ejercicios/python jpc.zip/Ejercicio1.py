preguntanombre=input("¿Cómo se llama?")
print(f"¡Bienvenido/a {preguntanombre}!")