#14. Modifica el programa anterior para que al final el programa muestre por pantalla solo los módulos suspensos.
