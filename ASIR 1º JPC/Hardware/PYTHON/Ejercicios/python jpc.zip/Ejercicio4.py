nombre=input(f"Dime tu nombre: ")
letra_inicial=nombre[0]
letra_final=nombre[-1]
tres_ult=nombre[-3:]
print(letra_inicial,letra_final)
print(nombre[0:2])
print(tres_ult)
print((nombre)[::-1])