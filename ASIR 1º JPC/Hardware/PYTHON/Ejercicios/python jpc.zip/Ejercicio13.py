#13. Escribir un programa que almacene los módulos del ciclo que estás realizando (Fundamentos del
#Hardware, Implantación de Sistemas operativos, Gestión de base de datos.) en una lista, pregunte
#al usuario la nota que ha sacado en cada módulo, y después las muestre por pantalla con el
#mensaje En <módulo> has sacado <nota> donde < módulo > es cada uno de los módulos de la lista
#y <nota> cada una de las correspondientes notas introducidas por el usuario.
