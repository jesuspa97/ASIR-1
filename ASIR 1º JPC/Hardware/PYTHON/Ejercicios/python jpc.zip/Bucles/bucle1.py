# 1. Imprime por pantalla los números del 1 al 20.
for i in range(1,21):
    print(i)






#while-->Repetir infinito 
#for-->Repetir bucle un numero de veces 1 al 20 
#in range(cifra que queremos que empiece "incluida", cifra que queremos que acabe +1)