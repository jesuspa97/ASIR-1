# 2. Imprime por pantalla los números pares del 14 al 32.
for i in range(14,33):
    if i%2==0:
        print(i)