lista=["maría", 9, "Juan", 3.2]
print(lista[0]) ###"""--> me dará el primer dato de la lista, en este caso maría"""
print(f"La nota {lista[0]} es {lista[1]}")