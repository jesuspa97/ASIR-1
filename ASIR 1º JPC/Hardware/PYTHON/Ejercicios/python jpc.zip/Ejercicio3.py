numero1=float(input(f"Escriba un número: "))
numero2=float(input(f"Escriba otro número"))
print((numero1+numero2)/2)
 