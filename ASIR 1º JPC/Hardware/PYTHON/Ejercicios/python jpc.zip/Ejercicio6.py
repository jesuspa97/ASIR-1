"""Pide al usuario su edad e indícula si es mayor de edad"""
edad=int(input("Dime tu edad :"))
if edad<18:
    print("Eres menor de edad")

else: 
    print("Eres mayor de edad")
    